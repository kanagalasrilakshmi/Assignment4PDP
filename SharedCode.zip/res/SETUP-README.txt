# Assignment4PDP

# HOW TO RUN THE JAR FILE
# 1. Create a folder (Name anything of your choice).
# 2. Add Assignment4PDP.jar file in that folder.
# 3. In that same folder add the file "tickrData.txt"(It can be copied from "res" folder).
    It is crucial since it has NASDAQ symbols, used for validation of tickrSymbols.
# 4. Now open the terminal in the same folder where tickrData.txt file and Assignment4PDP.jar file are placed.
# 5. There you can use the following commands and run the .jar file.
Configuration commands for text based and GUI based:
"Assignment4PDP.jar text" - for running text based console
"Assignment4PDP.jar gui" for running gui based console
# 6. Third-party-library json-simple-1.1.1.jar is used. To install it on IntelliJ go to File -> Project Structure -> Modules. There select the "+" icon and add the json-simple-1.1.1.jar file. Click on Apply and then Ok.
# JAVA SWING for creating the GUI is just an import statement.
# All other instructions will be prompted via the user interface to perform any operation.

