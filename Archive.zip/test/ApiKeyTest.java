import org.junit.Test;

import static org.junit.Assert.*;

public class ApiKeyTest {

  @Test
  public void getTickrSymbol() {
  }

  @Test
  public void callPresentPrice() {
  }

  @Test
  public void callPriceDate() {
  }
}