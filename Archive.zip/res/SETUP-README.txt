# Assignment4PDP

# HOW TO RUN THE JAR FILE
# 1. Create a folder (Name anything of your choice).
# 2. Add Assignment4PDP.jar file in that folder.
# 3. In that same folder add the file "tickrData.txt"(It can be copied from "res" folder).
    It is crucial since it has NASDAQ symbols, used for validation of tickrSymbols.
# 4. Now open the terminal in the same folder where tickrData.txt file and Assignment4PDP.jar file are placed.
# 5. There you can use the command java -jar Assignment4PDP.jar and run the .jar file successfully.


# TEST CASES FOR RUN COMMANDS

# TO CREATE a portfolio with 3 different stocks, a second portfolio with 2 different stocks and query their value on a specific date.
Note: Click enter after entering an answer throughout.
# 1. Run MVCStocks main.
# 2. Enter valid absolute path eg: "/Users/[yourSystemName]/Desktop/"
#    (or) give invalid eg "fh" it will create a default folder on your Desktop named "PortfolioBucket".
# 3. Enter C
# 4. Enter healthPf
# 5. Enter Y
# 6. Enter GOOG
# 7. Enter 10
# 8. Enter Y
# 9. Enter UBER
# 10. Enter 20
# 11. Enter Y
# 12. Enter AAL
# 13. Enter 30
# 14. Enter S
# 15. Enter C
# 16. Enter retirementPf
# 17. Enter Y
# 18. Enter TSLA
# 19. Enter 10
# 20. Enter Y
# 21. Enter MSFT
# 22. Enter 20
# 23. Enter S
# 24. Enter V
# 25. Enter healthPf
# 26. Enter D
# 27. Enter 2022-02-02
# 28. Enter V
# 29. Enter retirementPf
# 30. Enter D
# 31. Enter 2022-02-02
# 32. Enter Q

